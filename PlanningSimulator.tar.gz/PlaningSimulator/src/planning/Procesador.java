package planning;

public abstract class Procesador {

	private int id;
	private Tarea tarea;
	protected String tipo;  
	/*
	 * Un clock es el n�mero de unidades de tiempo que tienen que pasar para
	 * completar un c�mputo de tarea.
	 */
	private int clock;
	//private int razonDeClock;

	public Procesador(int id, int clock, String tipo) {

		this.id = id;
		this.clock = clock;
		this.tipo = tipo;
	}

	public boolean setTarea(Tarea tarea) {
		this.tarea = tarea;
		this.tarea.setTipoProcesador(this.tipo); 
		return true;
	}

	public boolean enEjecucion() {

		actualizar();
		return this.tarea != null;
	}

	private void actualizar() {

		if (this.tarea != null) {
			boolean hayTiempo = this.tarea.hayTiempo();
			if (this.tarea.finalizada() || !hayTiempo) {
				this.tarea = null;
				// El garbage collector se encarga del objeto 'tarea'.
			}
		}
	}

	@Override
	public String toString() {

		return "Processor [id=" + this.id + " / type=" + this.tipo + " / clock=" + this.clock +"]";
	}

	public Tarea getTarea() {

		return this.tarea;
	}
	
	public String getTipo() {
		return this.tipo;
	}
        
        public int getClock() {
		return this.clock;
	}
        
        public int getId() {
            return this.id;
        }

	public void computar() {
		this.tarea.computar(this.clock);
		//this.razonDeClock++;
		//if (this.razonDeClock == this.clock) {
			//this.tarea.computar();
			//this.razonDeClock = 0;
		//}
		//Control por si el computo realizado es mayor al computo de la tarea
		if (this.tarea.getCompRealizado() > this.tarea.getComputo()){
			int diff = this.tarea.getCompRealizado() - this.tarea.getComputo();
			this.tarea.restarComputoRealizado(diff);
		}
			
		
	}
        
        public void vaciar_proc(Tarea t) {
            this.tarea = t;
        }
}
