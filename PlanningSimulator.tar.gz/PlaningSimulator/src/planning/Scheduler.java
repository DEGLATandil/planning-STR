package planning;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Scheduler {

    private List<Tarea> tareas;
    private List<Procesador> procesadores;
    private Map<Integer, List<Tarea>> tareasListasPorPrioridad;
    private List<Tarea> tareasListas;
    private List<Tarea> tareasFallidas;
    private List<Integer> instanciasFallidas;
    private List<Integer> instanciasFinalizadas;
    private List<Tarea> tareasFinalizadas;
    private List<Tarea> tareasFallidasProcesador;
    private HashMap<String, Tarea> tareasInstancias;
    private HashMap<String, List<Object>> instanciaTareas;

    public Scheduler() {

        this.tareas = new LinkedList<Tarea>();
        this.procesadores = new LinkedList<Procesador>();
        this.tareasListasPorPrioridad = new HashMap<Integer, List<Tarea>>();
        this.tareasListas = new LinkedList<Tarea>();
        this.instanciasFallidas = new LinkedList<Integer>();
        this.instanciasFinalizadas = new LinkedList<Integer>();
        this.tareasFallidas = new LinkedList<Tarea>();
        this.tareasFinalizadas = new LinkedList<Tarea>();
        this.tareasFallidasProcesador = new LinkedList<Tarea>();
        this.tareasInstancias = new HashMap<String, Tarea>();
        this.instanciaTareas = new HashMap<String, List<Object>>();
        Global.getInstance().setTiempo(0);
    }
    
    
    public void addTarea(Tarea tarea) {

        this.tareas.add(tarea);
        Tarea aux = new TareaGrafica(tarea.getNombre(), tarea.getComputo(), tarea.getPeriodo(), tarea.getTiemInicio(), tarea.getProcesadoresCompatibles());
        this.tareasInstancias.put(tarea.getNombre(), aux.clone());
    }
    
    public List<Tarea> getTareas(){
        return this.tareas;
    }
    
    public List<Procesador> getProcesadores(){
        return this.procesadores;
    }

    public void addProcesador(Procesador procesador) {

        this.procesadores.add(procesador);
    }
    
    public List<Tarea> getTareasFinalizadas(){
        return this.tareasFinalizadas;
    }

    public List<Integer> getInstFallidas(){
        return this.instanciasFallidas;
    }
    
    public List<Integer> getInstFinalizadas(){
        return this.instanciasFinalizadas;
    }
    
    public StringBuffer[] hacer(int tiempoFinal, String tipo_prioridad, String actionDeadline, boolean velocidad) {
       int cant = (tiempoFinal/100000)+1;
       StringBuffer[] resultado = new StringBuffer[cant];
        for(int i=0;i<cant;i++){
            resultado[i] = new StringBuffer();
        }
        int indice = 0;
        int control = 100000;
       // int control = 50000;
        Mensaje res = new Mensaje();
        while (Global.getInstance().getTiempo() <= tiempoFinal) {
           if (Global.getInstance().getTiempo() == control){
              resultado[indice] = res.getMensaje();
              indice++; 
              control = control + 100000;
              res = new Mensaje();
           }
           //Para arreglar lo de EDF Y NO ABORT puse primero preparar iteracion y luego actualizar
           //Por ahora velocidad no se usa y siempre viene en false 
            if (velocidad) {
                this.tareasFinalizadas(actionDeadline, velocidad, res,tipo_prioridad);
                this.tareasAejecutar(actionDeadline);
            } else {
                this.tareasFinalizadas(actionDeadline, velocidad, res,tipo_prioridad);
                this.tareasAejecutar(actionDeadline);
                if (actionDeadline != "Abort") {
                    this.eliminar_repetidos();
                }
            }
            this.asignarTareasListas(velocidad,res);
            this.ejecutarInsTiempo(actionDeadline,res,tipo_prioridad);
            Global.getInstance().incrementarTiempo();
            if (tipo_prioridad == "EDF") {
                edfActualizarPrioridades();
            }
            
            
        }
        if (tiempoFinal < 100000){
            resultado[indice] = res.getMensaje();
        }else {
            if ((control-tiempoFinal)>0){
                resultado[indice] = res.getMensaje();
            }
        }
        return resultado;
    }
    
    
    //Elimina tareas repetidas con menor periodo 
    //Solo se ejecuta con los deadlines completitions
    private void eliminar_repetidos() {
        boolean suma = true;
        for(int i=0;i<this.tareasListas.size();){
            suma = true;
            for(int j=i+1;j<this.tareasListas.size();j++){
              if (this.tareasListas.get(i).getNombre() == this.tareasListas.get(j).getNombre()) {
                  if (this.tareasListas.get(i).getPeriodo() <= this.tareasListas.get(j).getPeriodo()) {
                      this.tareasListas.remove(i);
                      suma = false;
                  } else {
                      this.tareasListas.remove(j);
                  }
              } 
            }
            if (suma) {
                i++;
            }
        }
    }

    private void edfActualizarPrioridades() {
        for (int i = 0; i < this.tareasListas.size(); i++) {
            if (this.instanciaTareas.containsKey(this.tareasListas.get(i).getNombre())) {
                List<Object> info = this.instanciaTareas.get(this.tareasListas.get(i).getNombre());
                this.tareasListas.get(i).setPrioridad((Integer)info.get(2));
            } else {
                int prioridad = (this.tareasListas.get(i).getPeriodo() * this.tareasListas.get(i).getInstancia()) - Global.getInstance().getTiempo();
                //Esto es porque en la resta me estaba poniendo valores negativos.
                if ((prioridad <= 0)) {
                    this.tareasListas.get(i).setPrioridad(0);
                } else {
                    this.tareasListas.get(i).setPrioridad(prioridad);
                }
            }
        }

        for (int i = 0; i < this.procesadores.size(); i++) {
            if (this.procesadores.get(i).enEjecucion()) {
                if (this.instanciaTareas.containsKey(this.procesadores.get(i).getTarea().getNombre())) {
                    List<Object> info = this.instanciaTareas.get(this.procesadores.get(i).getTarea().getNombre());
                    this.procesadores.get(i).getTarea().setPrioridad((Integer)info.get(2));
                } else {
                    int prioridad = (this.procesadores.get(i).getTarea().getPeriodo() * this.procesadores.get(i).getTarea().getInstancia()) - Global.getInstance().getTiempo();
                    //Esto es porque en la resta me estaba poniendo valores negativos.
                    if ((prioridad <= 0)) {
                        this.procesadores.get(i).getTarea().setPrioridad(0);
                    } else {
                        this.procesadores.get(i).getTarea().setPrioridad(prioridad);
                    }
                }
            }
        }
    }

    //Realiza la iteracion y aumenta el calculo realizado
    private void ejecutarInsTiempo(String actionDeadline, Mensaje resultado, String priority) {
        StringBuffer mensaje = new StringBuffer();
        for (Procesador procesador : this.procesadores) {
            if (procesador.enEjecucion()) {
                mensaje.append(Global.getInstance().getTiempo());
                mensaje.append("\t : ");
                mensaje.append(procesador.toString());
                mensaje.append("\t execute ");
                mensaje.append(procesador.getTarea().toString());
                mensaje.append("\n");
                resultado.addMensaje(mensaje.toString());
                mensaje.setLength(0);
               // System.out.println(Global.getInstance().getTiempo()
               //         + "\t : " + procesador.toString() + "\t execute "
               //         + procesador.getTarea().toString());
                procesador.computar();

                Tarea tarea = procesador.getTarea();
                if (tarea.finalizada()) {
                   mensaje.append("Finished: ");
                    mensaje.append(tarea.toString());
                    mensaje.append("\n");
                    resultado.addMensaje(mensaje.toString());
                    mensaje.setLength(0);
                 //   System.out.println("Finished: " + tarea.toString());
                    this.tareasFinalizadas.add(tarea);
                    this.instanciasFinalizadas.add(tarea.getInstancia());
                    
                    if (actionDeadline != "Abort") {
                        if (this.instanciaTareas.containsKey(tarea.getNombre())) {
                            Tarea ultimaFallida = null;
                            for (int i = 0; i < this.tareasFallidas.size(); i++) {
                                if (tarea.getNombre() == this.tareasFallidas.get(i).getNombre()) {
                                    ultimaFallida = this.tareasFallidas.get(i);
                                }
                            }
                            this.instanciaTareas.remove(tarea.getNombre());
                            if (ultimaFallida == null) {
                                Tarea tareaNueva = this.tareasInstancias.get(tarea.getNombre());
                                tareaNueva.setInstancia(tareaNueva.getInstancia() + 1);
                                this.tareasInstancias.remove(tarea.getNombre());
                                this.tareasInstancias.put(tareaNueva.getNombre(), tareaNueva);
                            } else {
                                Tarea tareaNueva = ultimaFallida;
                                tareaNueva.setInstancia(tareaNueva.getInstancia() + 1);
                                this.tareasInstancias.remove(tarea.getNombre());
                                this.tareasInstancias.put(tareaNueva.getNombre(), tareaNueva);
                            }
                        } else {
                            Tarea tareaNueva = tarea;
                            tareaNueva.setInstancia(tareaNueva.getInstancia() + 1);
                            this.tareasInstancias.remove(tarea.getNombre());
                            this.tareasInstancias.put(tareaNueva.getNombre(), tareaNueva);
                        }
                    }
                }else{
                int tiempotarea = 0;
                if (actionDeadline != "Abort") {
                    if (tarea.getPeriodo() < Global.getInstance().getTiempo()){
                        tiempotarea = tarea.getTiemInicio() + tarea.getPeriodo() * tarea.getInstancia();
                    }else{
                        tiempotarea = tarea.getPeriodo();
                    }
                }else{
                    tiempotarea = tarea.getTiemInicio() + tarea.getPeriodo() * tarea.getInstancia();
                }
                //ACA DEBE CONTROLAR EL DEADLINE DE UNA TAREA QUE SE ESTA EJECUTANDO
               // boolean nohayTiempo = Global.getInstance().getTiempo() + 1 == tarea.getTiemInicio() + tarea.getPeriodo() * tarea.getInstancia();
                boolean nohayTiempo = Global.getInstance().getTiempo() + 1 == tiempotarea;
             //   boolean nofinalizada = tarea.getComputo() > tarea.getCompRealizado();
                boolean nofinalizada = true;
                if (nohayTiempo && nofinalizada) {
                    Tarea tarea_vacia = null;
                    procesador.vaciar_proc(tarea_vacia);
                    if (actionDeadline != "Abort") {
                        Tarea tareaInstancia = this.tareasInstancias.get(tarea.getNombre());
                        this.tareasInstancias.remove(tarea.getNombre());
                        Tarea tarea_clone = tareaInstancia.clone();
                        //Lo voy a necesitar
                        if (priority == "EDF"){
                            tarea_clone.setPrioridad(tarea.getPrioridad());
                        }
                        //this.tareasInstancias.put(this.tareasListas.get(i).getNombre(), tareaInstancia.clone());
                        this.tareasInstancias.put(tarea.getNombre(), tarea_clone);
                        mensaje.append(Global.getInstance().getTiempo());
                        mensaje.append(" Deadline: ");
                        mensaje.append(tareaInstancia.toString());
                        mensaje.append("\n");
                        resultado.addMensaje(mensaje.toString());
                        mensaje.setLength(0);
                      //  System.out.println(Global.getInstance().getTiempo()
                      //      + " Deadline: " + tareaInstancia.toString());
                        this.tareasFallidas.add(tareaInstancia);
                        this.instanciasFallidas.add(tareaInstancia.getInstancia());

                        List<Object> info = new ArrayList<Object>();
                        info.add(tarea.getInstancia());
                        info.add(tarea.getCompRealizado());
                        info.add(tarea.getPrioridad());
                        info.add(tarea.getTipoProcesador());
                        this.instanciaTareas.put(tarea.getNombre(), info);
                        /*Tarea tareaInstancia = this.tareasInstancias.get(tarea.getNombre());
                        this.tareasInstancias.remove(tarea.getNombre());
                        if (tarea.getInstancia() == tareaInstancia.getInstancia()) {
                            tareaInstancia = tareaInstancia.clone();
                            mensaje.append(Global.getInstance().getTiempo());
                            mensaje.append(" Deadline: ");
                            mensaje.append(tareaInstancia.toString());
                            mensaje.append("\n");
                            resultado.addMensaje(mensaje.toString());
                            mensaje.setLength(0);
                           //  System.out.println(Global.getInstance().getTiempo()
                          //          + " Deadline: " + tareaInstancia.toString());
                            this.tareasFallidas.add(tareaInstancia);
                            this.instanciasFallidas.add(tareaInstancia.getInstancia());
                            
                            this.tareasInstancias.put(tarea.getNombre(), tareaInstancia);
                            List<Object> info = new ArrayList<Object>();
                            info.add(tarea.getInstancia());
                            info.add(tarea.getCompRealizado());
                            info.add(tarea.getPrioridad());
                            info.add(tarea.getTipoProcesador());
                            this.instanciaTareas.put(tarea.getNombre(), info);
                        } else {
                            if (tarea.getInstancia() < tareaInstancia.getInstancia()) {
                                mensaje.append(Global.getInstance().getTiempo());
                                mensaje.append(" Deadline: ");
                                mensaje.append(tareaInstancia.toString());
                                mensaje.append("\n");
                                resultado.addMensaje(mensaje.toString());
                                mensaje.setLength(0);
                                // System.out.println(Global.getInstance().getTiempo()
                               //         + " Deadline: " + tareaInstancia.toString());
                                this.tareasFallidas.add(tareaInstancia);
                                this.instanciasFallidas.add(tareaInstancia.getInstancia());
                                
                                this.tareasInstancias.put(tarea.getNombre(), tareaInstancia);
                                List<Object> info = new ArrayList<Object>();
                                info.add(tarea.getInstancia());
                                info.add(tarea.getCompRealizado());
                                info.add(tarea.getPrioridad());
                                info.add(tarea.getTipoProcesador());
                                this.instanciaTareas.put(tarea.getNombre(), info);
                            } else {
                                mensaje.append(Global.getInstance().getTiempo());
                                mensaje.append(" Deadline: ");
                                mensaje.append(tareaInstancia.toString());
                                mensaje.append("\n");
                                resultado.addMensaje(mensaje.toString());
                                mensaje.setLength(0);
                                // System.out.println(Global.getInstance().getTiempo()
                               //         + " Deadline: " + tareaInstancia.toString());
                                this.tareasFallidas.add(tareaInstancia);
                                this.instanciasFallidas.add(tareaInstancia.getInstancia());
                                
                                this.tareasInstancias.put(tarea.getNombre(), tareaInstancia.clone());
                                List<Object> info = new ArrayList<Object>();
                                info.add(tarea.getInstancia());
                                info.add(tarea.getCompRealizado());
                                info.add(tarea.getPrioridad());
                                info.add(tarea.getTipoProcesador());
                                this.instanciaTareas.put(tarea.getNombre(), info);
                            }
                        }
                   */ } else {
                        mensaje.append(Global.getInstance().getTiempo());
                        mensaje.append(" Deadline: ");
                        mensaje.append(tarea.toString());
                        mensaje.append("\n");
                        resultado.addMensaje(mensaje.toString());
                        mensaje.setLength(0);
                        // System.out.println(Global.getInstance().getTiempo()
                       //         + " Deadline: " + tarea.toString());
                        this.tareasFallidas.add(tarea);
                        this.instanciasFallidas.add(tarea.getInstancia());
                    }
                }
                }
            }
        }
    }

        //Controla que las tareas que llegaron a su Deadline
    private void tareasFinalizadas(String actionDeadline, boolean velocidad, Mensaje resultado, String priority) {                 
        StringBuffer mensaje = new StringBuffer();
        for (int i = 0; i < this.tareasListas.size(); i++) {
           // if (this.tareasListas.get(i).getNombre().contains("t7")){
           //     System.out.println(Global.getInstance().getTiempo()+ "-" +this.tareasListas.get(i).getPeriodo());
           // }
            int tiempotarea = 0;
            if (actionDeadline != "Abort") {
                if (this.tareasListas.get(i).getPeriodo() < Global.getInstance().getTiempo()){
                    tiempotarea = this.tareasListas.get(i).getTiemInicio() + this.tareasListas.get(i).getPeriodo() * this.tareasListas.get(i).getInstancia();
                }else{
                    tiempotarea = this.tareasListas.get(i).getPeriodo();
                }
            }else{
                tiempotarea = this.tareasListas.get(i).getTiemInicio() + this.tareasListas.get(i).getPeriodo() * this.tareasListas.get(i).getInstancia();
            }
            // if (this.tareasListas.get(i).getNombre().contains("t7")){
            //    System.out.println(Global.getInstance().getTiempo()+ "-" +tiempotarea+ "-" +this.tareasListas.get(i).getInstancia()+"-"+ this.tareasListas.get(i).getPeriodo());
           // }
//int tiempotarea = this.tareasListas.get(i).getPeriodo();
            
            if (!(Global.getInstance().getTiempo() < tiempotarea)) {
                if (actionDeadline != "Abort") {
                    Tarea tareaInstancia = this.tareasInstancias.get(this.tareasListas.get(i).getNombre());
                    this.tareasInstancias.remove(this.tareasListas.get(i).getNombre());
                    Tarea tarea_clone = tareaInstancia.clone();
                    
                    if (priority == "EDF"){
                        tarea_clone.setPrioridad(this.tareasListas.get(i).getPrioridad());
                    }
                    //this.tareasInstancias.put(this.tareasListas.get(i).getNombre(), tareaInstancia.clone());
                    this.tareasInstancias.put(this.tareasListas.get(i).getNombre(), tarea_clone);
                   mensaje.append(Global.getInstance().getTiempo());
                    mensaje.append(" Deadline: ");
                    mensaje.append(tareaInstancia.toString());
                    mensaje.append("\n");
                    resultado.addMensaje(mensaje.toString());
                    mensaje.setLength(0);
                  //  System.out.println(Global.getInstance().getTiempo()
                  //      + " Deadline: " + tareaInstancia.toString());
                    this.tareasFallidas.add(tareaInstancia);
                    this.instanciasFallidas.add(tareaInstancia.getInstancia());
                            
                    List<Object> info = new ArrayList<Object>();
                    info.add(this.tareasListas.get(i).getInstancia());
                    info.add(this.tareasListas.get(i).getCompRealizado());
                    info.add(this.tareasListas.get(i).getPrioridad());
                    info.add(this.tareasListas.get(i).getTipoProcesador());
                    this.instanciaTareas.put(this.tareasListas.get(i).getNombre(), info);
                } else {
                    Tarea tarea = this.tareasListas.get(i);
                   mensaje.append(Global.getInstance().getTiempo());
                    mensaje.append(" Deadline: ");
                    mensaje.append(tarea.toString());
                    mensaje.append("\n");
                    resultado.addMensaje(mensaje.toString());
                    mensaje.setLength(0);
                   // System.out.println(Global.getInstance().getTiempo()
                   //         + " Deadline: " + tarea.toString());
                    this.tareasFallidas.add(tarea);
                    this.instanciasFallidas.add(tarea.getInstancia());
                    
                    this.tareasListas.remove(tarea);
                }
            }

        }
        
        //Falta revisar las fallidas en procesador
        
        
    }

    //Recorre toda la lista de Tareas listas y trata de asignarlas en caso de poder
    private void asignarTareasListas(boolean velocidad, Mensaje resultado) {
        List<Tarea> tareasasignadas = new LinkedList<Tarea>();
        List<Tarea> tareasNoasignadas = new LinkedList<Tarea>();
        for (int i = 0; i < this.tareasListas.size();) {
            Tarea aux = this.tareaMenorPrioridad();
            this.tareasListas.remove(aux);
            if (!this.asignarTarea(aux, velocidad,resultado)) {
                tareasasignadas.add(aux);
            }
        }

        for (int j = 0; j < tareasasignadas.size(); j++) {
            this.tareasListas.add(tareasasignadas.get(j));
        }

        //############# SHOW #############//
        resultado.addMensaje("###################################### \n");
      //  System.out.println("######################################");
        resultado.addMensaje("Tasks list pending: \n");
     //   System.out.println("Tasks list pending: ");
        StringBuffer mensaje = new StringBuffer();
        for (int j = 0; j < this.tareasListas.size(); j++) {
            mensaje.append(this.tareasListas.get(j));
            mensaje.append("\n");
            resultado.addMensaje(mensaje.toString());
            mensaje.setLength(0);
       //     System.out.println(this.tareasListas.get(j));
        }
        resultado.addMensaje("###################################### \n");
       // System.out.println("######################################");
            //###############################//
    

    }

    //Controla que tarea esta lista para ejecutarse y la agrega a la lista.
    private void tareasAejecutar(String actionDeadline) {
        Iterator<Tarea> it = this.tareas.iterator();
        while (it.hasNext()) {
            Tarea tarea = it.next();
            if (tarea.debeEjecutarse()) {
                int prioridad = tarea.getPrioridad();
                if (!this.tareasListasPorPrioridad.containsKey(prioridad)) {
                    this.tareasListasPorPrioridad.put(prioridad,
                            new LinkedList<Tarea>());
                }
                List<Tarea> lista = this.tareasListasPorPrioridad.get(prioridad);
                Tarea tareaClonada = tarea.clone();
                if (actionDeadline != "Abort") {
                    if (this.instanciaTareas.containsKey(tareaClonada.getNombre())) {
                        List<Object> info = this.instanciaTareas.get(tareaClonada.getNombre());
                        tareaClonada.setInstancia((Integer)info.get(0));
                        tareaClonada.setCompRealizado((Integer)info.get(1));
                        if ((Integer)info.get(1) >= 0) {
                            tareaClonada.setPeriodo(tareaClonada.getPeriodo() * (this.tareasInstancias.get(tareaClonada.getNombre()).getInstancia()));
                        }
                    //    System.out.println(info.get(2));
                    //    System.out.println(info.get(3));
                        tareaClonada.setPrioridad((Integer)info.get(2));
                        tareaClonada.setTipoProcesador((String)info.get(3));
                    } 
                }
                
                lista.add(tareaClonada);
                this.tareasListas.add(tareaClonada);
            }
                
        }
    }

    //Retorna la tarea de menor prioridad lista para ejecutarse
    private Tarea tareaMenorPrioridad() {
        Tarea menorprioridad = null;
        if (this.tareasListas.size() > 0) {
            menorprioridad = this.tareasListas.get(0);
            for (int i = 1; i < this.tareasListas.size(); i++) {
                if (menorprioridad.getPrioridad() > this.tareasListas.get(i).getPrioridad()) {
                    menorprioridad = this.tareasListas.get(i);
                }
            }
        }
        return menorprioridad;
    }

    //Se encarga de asignar las tareas listas o mantenerlas en dichas lista hasta poder ejecutarse
    private boolean asignarTarea(Tarea tarea, boolean velocidad,Mensaje resultado) {
        if (this.asignarProcesadorLibre(tarea, velocidad,resultado)) {
            return true;
        } else {
            if (!velocidad) {
                if (this.cambiarTareaProcesador(tarea,resultado)) {
                    return true;
                } else {
                    return false;
                }
            } else {
            //    System.out.println("Prioridad de velocidad y no se pudo asignar");
                return false;
            }
        }
    }

    //Asigna si es posible la tarea a un procesador compatible y libre.
    private boolean asignarProcesadorLibre(Tarea tarea, boolean velocidad, Mensaje resultado) {
        Procesador procesadorlibre = null;
        List<Procesador> procesadoresTarea = tarea.getProcesadoresCompatibles();
        for (int i = 0; i < procesadoresTarea.size(); i++) {
            if (!velocidad) {
                procesadorlibre = procesadoresTarea.get(i);
                if ((!procesadorlibre.enEjecucion()) && ((tarea.getTipoProcesador() == null) || (procesadorlibre.getTipo() == tarea.getTipoProcesador()))) {
                    if (procesadorlibre.setTarea(tarea)) {
                        return true;
                    }
                }
            } else {
                procesadorlibre = this.getProcesadorMasRapido(tarea);
                if (procesadorlibre != null) {
                    if (procesadorlibre.enEjecucion()) {
                        //Cambio de contexto
                        Tarea tareaDelProcesador = procesadorlibre.getTarea();
                        if (!this.tareasListasPorPrioridad.containsKey(tareaDelProcesador.getPrioridad())) {
                            this.tareasListasPorPrioridad.put(tareaDelProcesador.getPrioridad(),
                                    new LinkedList<Tarea>());
                        }
                        this.tareasListasPorPrioridad.get(tareaDelProcesador.getPrioridad()).add(tareaDelProcesador);
                        this.tareasListas.add(tareaDelProcesador);
                        if (procesadorlibre.setTarea(tarea)) {
                           // resultado.addMensaje(Global.getInstance().getTiempo() + " Context switch: \n");
                        //    System.out.println(Global.getInstance().getTiempo()
                        //            + " Context switch:");
                        }
                        return true;
                    } else {
                        if (procesadorlibre.setTarea(tarea)) {
                            return true;
                        }
                    }
                } else {
                    return false;
                }
            }
        }
        return false;
    }

    //Retorna el procesador mas rápido para la tarea 
    private Procesador getProcesadorMasRapido(Tarea tarea) {
        Procesador procesadorRapido = null;
        Procesador finalMasRapido = null;
        int vel = -1;
        for (int i = 0; i < tarea.getProcesadoresCompatibles().size(); i++) {
            procesadorRapido = tarea.getProcesadoresCompatibles().get(i);
            if (procesadorRapido.getClock() >= vel) {
                if (procesadorRapido.enEjecucion()) {
                    if ((tarea.getPrioridad() < procesadorRapido.getTarea().getPrioridad()) && ((tarea.getTipoProcesador() == null) || (procesadorRapido.getTipo() == tarea.getTipoProcesador()))) {
                        vel = procesadorRapido.getClock();
                        finalMasRapido = procesadorRapido;
                    }
                } else {
                    vel = procesadorRapido.getClock();
                    finalMasRapido = procesadorRapido;
                }
            }
        }
        return finalMasRapido;
    }

    //Asigna una tarea a un procesador compatible si es posible, realizando un cambio de contexto
    private boolean cambiarTareaProcesador(Tarea tarea, Mensaje resultado) {
        List<Procesador> procesadoresTarea = tarea.getProcesadoresCompatibles();
        //Primero buscar procesador candidato (el que tenga la tarea de menor prioridad)
        Procesador procesador = getProcesadorVictima(procesadoresTarea, tarea);
        if (procesador != null) {
            if ((tarea.getTipoProcesador() == null) || (procesador.getTipo() == tarea.getTipoProcesador())) {
                // Cambio de contexto:
                Tarea tareaDelProcesador = procesador.getTarea();
                if (tareaDelProcesador != null) {
                    if (!this.tareasListasPorPrioridad.containsKey(tareaDelProcesador.getPrioridad())) {
                        this.tareasListasPorPrioridad.put(tareaDelProcesador.getPrioridad(),
                                new LinkedList<Tarea>());
                    }
                    this.tareasListasPorPrioridad.get(tareaDelProcesador.getPrioridad()).add(tareaDelProcesador);
                    this.tareasListas.add(tareaDelProcesador);
                    if (procesador.setTarea(tarea)) {
                     //   resultado.addMensaje(Global.getInstance().getTiempo() + " Context switch: \n");
                    //    System.out.println(Global.getInstance().getTiempo()
                    //            + " Context switch:");
                    }
                    return true;
                }
            }
        }

        return false;
    }

    //Retorna el procesador en el cual se realizara el cambio de contexto
    private Procesador getProcesadorVictima(List<Procesador> procesadores, Tarea tarea) {
        Procesador procesador = null;
        Tarea tareaProc = null;
        for (int i = 0; i < procesadores.size(); i++) {
            tareaProc = procesadores.get(i).getTarea();
            if (tareaProc != null) {
                if (tarea.getPeriodo() < tareaProc.getPrioridad()) {
                    procesador = procesadores.get(i);
                }
            }
        }
        return procesador;
    }

	//FINALIZA EL CODIGO NUEVO
    private void actualizarPrioridades(String tipo_prioridad) {
        for (int i = 0; i < this.tareas.size(); i++) {
            if (tipo_prioridad == "PF") {
                this.tareas.get(i).setPrioridad(this.tareas.get(i).getPeriodo());
            } else {
                //Es una prioridad EDF
                int prioridad;

                prioridad = (this.tareas.get(i).getPeriodo() * this.tareas.get(i).getInstancia()) - Global.getInstance().getTiempo();

                //Esto es porque en la resta me estaba poniendo valores negativos.
                if ((prioridad <= 0)) {
                    this.tareas.get(i).setPrioridad(0);
                } else {
                    this.tareas.get(i).setPrioridad(prioridad);
                }

            }
			//TODO: Coment
            //System.out.println("Prioridad de "+this.tareas.get(i).getNombre()+" : "+((Integer)this.tareas.get(i).getPrioridad()).toString());
        }

        for (int i = 0; i < this.tareasListas.size(); i++) {
            if (tipo_prioridad == "PF") {
                this.tareasListas.get(i).setPrioridad(this.tareasListas.get(i).getPeriodo());
            } else {
                //Es una prioridad EDF
                int prioridad;

                prioridad = (this.tareasListas.get(i).getPeriodo() * this.tareasListas.get(i).getInstancia()) - Global.getInstance().getTiempo();

                //Esto es porque en la resta me estaba poniendo valores negativos.
                if ((prioridad <= 0)) {
                    this.tareasListas.get(i).setPrioridad(0);
                } else {
                    this.tareasListas.get(i).setPrioridad(prioridad);
                }

            }
			//TODO: Coment
            //System.out.println("Prioridad de "+this.tareas.get(i).getNombre()+" : "+((Integer)this.tareas.get(i).getPrioridad()).toString());
        }
    }

    private void actualizarPrioridadesTareasProcesador() {
        for (int i = 0; i < this.procesadores.size(); i++) {
            if (this.procesadores.get(i).enEjecucion()) {
                for (int j = 0; j < this.tareas.size(); j++) {
                    if (this.procesadores.get(i).getTarea().getNombre() == this.tareas.get(j).getNombre()) {
                        this.procesadores.get(i).getTarea().setPrioridad(this.tareas.get(j).getPrioridad());
                    }
                }
            }
        }
    }

    //No se usa (Se puede borrar)    
    private void tareasFallidas(String actionDeadline) {
        /*
         * Eliminar tareas que han llegado al deadline.
         */
        if (actionDeadline == "Abort") {
            Iterator<Tarea> iterador = this.tareasListas.iterator();
            while (iterador.hasNext()) {
                Tarea tarea = iterador.next();
                if (tarea.fallo()) {
                  //  System.out.println(Global.getInstance().getTiempo()
                  //          + " Deadline: " + tarea.toString());
                    iterador.remove();
                    this.tareasListasPorPrioridad.get(tarea.getPrioridad()).remove(
                            tarea);
                    this.tareasFallidas.add(tarea);
                    this.instanciasFallidas.add(tarea.getInstancia());
                }
            }
            /*
             * Y las que están en los procesadores.
             */
            for (Procesador procesador : this.procesadores) {
                Tarea tarea = procesador.getTarea();
                if (tarea != null && tarea.fallo()) {
                  //  System.out.println(Global.getInstance().getTiempo()
                  //          + " Deadline: " + tarea.toString());
                    this.tareasFallidas.add(tarea);
                    this.instanciasFallidas.add(tarea.getInstancia());
                }
            }
        } else {
            for (int i = 0; i < this.tareasListas.size(); i++) {
                Tarea tarea = this.tareasListas.get(i);
                if (tarea.fallo()) {
                    Tarea tareaInstancia = this.tareasInstancias.get(tarea.getNombre());
                    this.tareasInstancias.remove(tarea.getNombre());
                    this.tareasInstancias.put(tarea.getNombre(), tareaInstancia.clone());
                  //  System.out.println(Global.getInstance().getTiempo()
                  //          + " Deadline: " + tareaInstancia.toString());
                    this.tareasFallidas.add(tareaInstancia);
                    this.instanciasFallidas.add(tareaInstancia.getInstancia());
                    
                    List<Object> info = new ArrayList<Object>();
                    info.add(tarea.getInstancia());
                    info.add(tarea.getCompRealizado());
                    info.add(tarea.getTipoProcesador());
                    this.instanciaTareas.put(tarea.getNombre(), info);
                }
            }
            /*
             * Y las que están en los procesadores.
             */
            for (Procesador procesador : this.procesadores) {

                Tarea tarea = procesador.getTarea();

                if (tarea != null && tarea.fallo()) {
                    Tarea tareaInstancia = this.tareasInstancias.get(tarea.getNombre());
                    this.tareasInstancias.remove(tarea.getNombre());
                    this.tareasInstancias.put(tarea.getNombre(), tareaInstancia.clone());
                  //  System.out.println(Global.getInstance().getTiempo()
                  //          + " Deadline: " + tareaInstancia.toString());
                    this.tareasFallidas.add(tareaInstancia);
                    this.instanciasFallidas.add(tareaInstancia.getInstancia());
                    
                    List<Object> info = new ArrayList<Object>();
                    info.add(tarea.getInstancia());
                    info.add(tarea.getCompRealizado());
                    info.add(tarea.getTipoProcesador());
                    this.instanciaTareas.put(tarea.getNombre(), info);
                }
            }
        }

    }

    private void prepararIteracion() {

        /*
         * Asignar tareas a los procesadores.
         */
        //Nuevo asignador de tareas
        for (Integer prioridadActual : this.tareasListasPorPrioridad.keySet()) {
            Iterator<Tarea> it = this.tareasListasPorPrioridad.get(prioridadActual).iterator();

            while (it.hasNext()) {
                Tarea tarea = it.next();
                List<Procesador> procesadoresTarea = tarea.getProcesadoresCompatibles();
                boolean tareaAsignada = false;
                for (int i = 0; i < procesadoresTarea.size(); i++) {
                    Procesador procesadorLibre = procesadoresTarea.get(i);
                    if (!procesadorLibre.enEjecucion()) {
                        if (procesadorLibre.setTarea(tarea)) {
                            this.tareasListas.remove(tarea);
                            tareaAsignada = true;
                            it.remove();
                            break;
                        }
                    }
                }
                if (!tareaAsignada) {
                    //Primero buscar procesador candidato (el que tenga la tarea de menor prioridad)
                    Procesador procesador = getProcesadorUsar(procesadoresTarea);
                    // Cambio de contexto:
                    Tarea tareaDelProcesador = procesador.getTarea();
                    if (tareaDelProcesador != null && tareaDelProcesador.getPrioridad() > tarea.getPrioridad()) {
                        this.tareasListasPorPrioridad.get(tareaDelProcesador.getPrioridad()).add(tareaDelProcesador);
                        this.tareasListas.add(tareaDelProcesador);
                        if (procesador.setTarea(tarea)) {
                           // System.out.println(Global.getInstance().getTiempo()
                           //         + " Context switch:");
                            it.remove();
                            this.tareasListas.remove(tarea);
                        }
                        break;
                    }
                }
            }
        }

    }

    private Procesador getProcesadorUsar(List<Procesador> procesadores) {
        Tarea tarea = procesadores.get(0).getTarea();
        Procesador procesador = procesadores.get(0);
        for (int i = 1; i < procesadores.size(); i++) {
            if (tarea.getPeriodo() < procesadores.get(i).getTarea().getPrioridad()) {
                tarea = procesadores.get(i).getTarea();
                procesador = procesadores.get(i);
            }
        }
        return procesador;
    }

    private void iterar(String tipoDeadline) {

        for (Procesador procesador : this.procesadores) {
            if (procesador.enEjecucion()) {
               // System.out.println(Global.getInstance().getTiempo()
               //         + "\t : " + procesador.toString() + "\t execute "
               //         + procesador.getTarea().toString());
                procesador.computar();
				//TODO:
                //Se agrega para controlar deadline
                if (tipoDeadline == "Abort") {
                    Tarea tarea = procesador.getTarea();
                    boolean nohayTiempo = Global.getInstance().getTiempo() + 1 == tarea.getTiemInicio() + tarea.getPeriodo() * tarea.getInstancia();
                    boolean nofinalizada = tarea.getComputo() > tarea.getCompRealizado();
                    if (nohayTiempo && nofinalizada) {
                       // System.out.println(Global.getInstance().getTiempo()
                       //         + " Deadline: " + tarea.toString());
                        this.tareasFallidas.add(tarea);
                        this.instanciasFallidas.add(tarea.getInstancia());
                    }
                    if (tarea.finalizada()) {
                       // System.out.println("Finished: " + tarea.toString());
                        this.tareasFinalizadas.add(tarea);
                        this.instanciasFinalizadas.add(tarea.getInstancia());
                    }
                } else {
                    Tarea tarea = procesador.getTarea();
                    boolean nohayTiempo = Global.getInstance().getTiempo() + 1 == tarea.getTiemInicio() + tarea.getPeriodo() * tarea.getInstancia();
                    boolean nofinalizada = tarea.getComputo() > tarea.getCompRealizado();
                    if (tarea != null && nohayTiempo && nofinalizada) {
                        Tarea tareaInstancia = this.tareasInstancias.get(tarea.getNombre());
                        this.tareasInstancias.remove(tarea.getNombre());
                        this.tareasInstancias.put(tarea.getNombre(), tareaInstancia.clone());
                       // System.out.println(Global.getInstance().getTiempo()
                       //         + " Deadline: " + tareaInstancia.toString());
                        this.tareasFallidas.add(tareaInstancia);
                        this.instanciasFallidas.add(tarea.getInstancia());
                        
                        List<Object> info = new ArrayList<Object>();
                        info.add(tarea.getInstancia());
                        info.add(tarea.getCompRealizado());
                        info.add(tarea.getTipoProcesador());
                        this.instanciaTareas.put(tarea.getNombre(), info);
                    }
                    if (tarea.finalizada()) {
                       // System.out.println("Finished: " + tarea.toString());
                        this.tareasFinalizadas.add(tarea);
                        this.instanciasFinalizadas.add(tarea.getInstancia());
                        if (this.instanciaTareas.containsKey(tarea.getNombre())) {
                            List<Object> info = this.instanciaTareas.get(tarea.getNombre());
                            info.set(0, (this.tareasInstancias.get(tarea.getNombre()).getInstancia() + 1));
                            info.set(1, 0);
                            Tarea tareaNueva = this.tareasInstancias.get(tarea.getNombre());
                            tareaNueva.setInstancia(tareaNueva.getInstancia() + 1);
                            this.tareasInstancias.remove(tarea.getNombre());
                            this.tareasInstancias.put(tareaNueva.getNombre(), tareaNueva);
                        }
                    }
                }
            }
        }
    }

    /**
     * @post Genera el mapa de las tareas listas agrupadas por prioridad.
     */
    private void actualizarMapa(String actionDeadline) {
        if (actionDeadline == "Abort") {
            Iterator<Tarea> it = this.tareas.iterator();
            while (it.hasNext()) {
                Tarea tarea = it.next();
                if (tarea.debeEjecutarse()) {
                    int prioridad = tarea.getPrioridad();
                    if (!this.tareasListasPorPrioridad.containsKey(prioridad)) {
                        this.tareasListasPorPrioridad.put(prioridad,
                                new LinkedList<Tarea>());
                    }
                    List<Tarea> lista = this.tareasListasPorPrioridad.get(prioridad);
                    Tarea tareaClonada = tarea.clone();
                    lista.add(tareaClonada);
                    this.tareasListas.add(tareaClonada);
                }
            }
        } else {
            Iterator<Tarea> it = this.tareas.iterator();
            while (it.hasNext()) {
                Tarea tarea = it.next();
                if (tarea.debeEjecutarse()) {
                    int prioridad = tarea.getPrioridad();
                    if (!this.tareasListasPorPrioridad.containsKey(prioridad)) {
                        this.tareasListasPorPrioridad.put(prioridad,
                                new LinkedList<Tarea>());
                    }
                    List<Tarea> lista = this.tareasListasPorPrioridad.get(prioridad);
                    Tarea tareaClonada = tarea.clone();
                    if (this.instanciaTareas.containsKey(tareaClonada.getNombre())) {
                        List<Object> info = this.instanciaTareas.get(tareaClonada.getNombre());
                        tareaClonada.setInstancia((Integer)info.get(0));
                        tareaClonada.setCompRealizado(((Integer)info.get(1)));
                        if ((Integer)info.get(1) > 0) {
                            tareaClonada.setPeriodo(tareaClonada.getPeriodo() * (this.tareasInstancias.get(tareaClonada.getNombre()).getInstancia()));
                        }
                        tareaClonada.setTipoProcesador((String) info.get(3));
                    }
                    lista.add(tareaClonada);
                    this.tareasListas.add(tareaClonada);
                }
            }
        }

    }

    public List<Tarea> getTareasFallidas() {

        return this.tareasFallidas;
    }
}
