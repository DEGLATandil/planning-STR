/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planning;

/**
 *
 * @author diego
 */
public class Mensaje {
    private StringBuffer mensaje;
    
    public Mensaje() {
        this.mensaje  = new StringBuffer();
    }
    
    public void addMensaje(String res) {
        this.mensaje.append(res);
    }
    
    public StringBuffer getMensaje() {
        return this.mensaje;
    }
}
