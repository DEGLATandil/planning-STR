package planning;


public class ProcesadorGrafico extends Procesador {

	public ProcesadorGrafico(int id, int clock, String tipo) {
		super(id, clock, tipo);
	}

	@Override
	public boolean setTarea(Tarea tarea) {

		if (tarea.getClass() == TareaGrafica.class) {
			super.setTarea(tarea);
			return true;
		} else {
			
			return false;
		}
	}

}
