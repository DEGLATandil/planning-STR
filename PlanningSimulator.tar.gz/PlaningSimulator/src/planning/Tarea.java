package planning;

import java.util.LinkedList;
import java.util.List;

public abstract class Tarea implements Cloneable {

	protected String nombre;
	protected int computo;
	/*
	 * Período
	 * - Igual al deadline
	 * - Aleatorio entre 400-7000
	 */
	protected int periodo;
	protected int inicio;
	protected int prioridad;
	protected int instancia;
	protected int computoRealizado;
	//procesadores determina en los procesadores que se puede ejecutar la tarea
	protected List<Procesador> procesadores;
	//El tipo se setea con el tipo de procesador donde se comienza a ejecutar, no es tipo de tare
	protected String tipoProcesador;



	public Tarea(String nombre, int computo, int periodo, int inicio, List<Procesador> proce) {

		this.nombre = nombre;
		this.computo = computo;
		this.periodo = periodo;
		this.inicio = inicio;
		this.prioridad = this.periodo;
		this.procesadores = proce;
		this.tipoProcesador = null;
	}

	public Tarea(String nombre, int computo, int periodo, int inicio,
			List<Procesador> proce, int instancia) {

		this.nombre = nombre;
		this.computo = computo;
		this.periodo = periodo;
		this.inicio = inicio;
		this.prioridad = periodo;
		this.procesadores = proce;
		this.instancia = instancia;
		this.tipoProcesador = null;
	}
        
        
	public int getPrioridad() {

		return this.prioridad;
	}

	public int getComputo() {

		return this.computo;
	}

	public int getPeriodo() {

		return this.periodo;
	}

	public int getInstancia() {
		return this.instancia;
	}
	
	public void setInstancia(int instanciaActual){
		this.instancia = instanciaActual;
	}

	public boolean debeEjecutarse() {

		return Global.getInstance().getTiempo() >= this.inicio + this.periodo
				* this.instancia
				&& !finalizada();
	}

	@Override
	public String toString() {

		return "Task [n=" + this.nombre + ", c=" + this.computo + ", T="
				+ this.periodo + ", phi=" + this.inicio + ", p="
				+ this.prioridad + ", i=" + this.instancia + ", cr="
				+ this.computoRealizado + " ProcType="+ this.tipoProcesador +"]";
	}

	public void computar(int clock) {
		this.computoRealizado += clock;
	}
	
	//Quita computoRealizado en caso de ser mayor al computo de la tarea 
	//Evita que una tarea pueda realizar mas computo de lo que debe
	public void restarComputoRealizado(int diff) {
		this.computoRealizado -= diff;
	}

	public boolean finalizada() {
		return (this.computo == this.computoRealizado);
	}

	@Override
	public Tarea clone() {
		this.instancia++;
		return nuevaInstancia();
	}

	protected abstract Tarea nuevaInstancia();

	public boolean hayTiempo() {

		boolean hayTiempo = Global.getInstance().getTiempo() < this.inicio + this.periodo * this.instancia;
		return hayTiempo;
	}

	public boolean fallo() {

		return !hayTiempo() && !finalizada();
	}
	
	public boolean puedeSeguir() {
		boolean hayTiempo = Global.getInstance().getTiempo()+1 < this.inicio + this.periodo * this.instancia;
		boolean nofinalizada = this.computo > this.computoRealizado+1;
		return !hayTiempo && nofinalizada;
	}

	public String getNombre() {

		return this.nombre;
	}
	
	public List<Procesador> getProcesadoresCompatibles(){
		return this.procesadores;
	}
	
	public void setProcesadoresCompatibles(List<Procesador> procesadorescomp){
		this.procesadores = procesadorescomp;
	}
	
	public void setPrioridad(int nuevaPrioridad) {
		this.prioridad = nuevaPrioridad;
	}
	
	public int getTiemInicio() {
		return this.inicio;
	}
	
	
	public int getCompRealizado(){
		return this.computoRealizado;
	}
	
	public void setCompRealizado(int comp){
		this.computoRealizado = comp;
	}
	
	public void setPeriodo(int per){
		this.periodo = per;
	}
	
	public String getTipoProcesador(){
		return this.tipoProcesador;
	}
	
	public void setTipoProcesador(String tipoProc){
		this.tipoProcesador = tipoProc;
	}
        
        public String getInfo() {

		return "Task [n=" + this.nombre + ", c=" + this.computo + ", T="
				+ this.periodo + ", phi=" + this.inicio + ", p="
				+ this.prioridad + " ProcType="+ this.getTiposProc() +"]";
	}
        
        public String getTiposProc() {
            Mensaje tiposProc = new Mensaje();
            LinkedList<String> proc = new LinkedList<String>();
            for(int i = 0; i < this.procesadores.size(); i++) {
                if(!this.existe(this.procesadores.get(i).getTipo(),proc)) {
                 proc.add(this.procesadores.get(i).getTipo());
                }
            }
            for(int i = 0; i < proc.size(); i++) {
                tiposProc.addMensaje(proc.get(i)+"-");
            }
            //Le elimino el ultimo caracter que es un -
            return tiposProc.getMensaje().substring(0, tiposProc.getMensaje().length()-1); 
        }
        
        public boolean existe(String valor, LinkedList<String> tipoPro) {
            boolean existe = false;
            for(int i = 0; i < tipoPro.size(); i++) {
                if (tipoPro.get(i) == valor)
                    return true;
            }
            return false;
        }
	
}
