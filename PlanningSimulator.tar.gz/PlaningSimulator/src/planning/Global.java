package planning;

public class Global {

	private static Global instance = new Global();
	private int tiempo;

	public static Global getInstance() {

		return instance;
	}

	public void incrementarTiempo() {

		this.tiempo++;
	}

	public int getTiempo() {

		return this.tiempo;
	}

	public void setTiempo(int tiempo) {
		this.tiempo = tiempo;
	}
}
