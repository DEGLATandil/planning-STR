package planning;

import java.util.List;


public class TareaGrafica extends Tarea {
	
	public TareaGrafica(String nombre, int computo, int periodo, int inicio,
			List<Procesador> proce) {
		super(nombre, computo, periodo, inicio, proce);
	}

	public TareaGrafica(String nombre, int computo, int periodo, int inicio,
			List<Procesador> proce, int instancia) {
		super(nombre, computo, periodo, inicio, proce, instancia);
	}

	@Override
	protected Tarea nuevaInstancia() {

		return new TareaGrafica(this.nombre, this.computo, this.periodo, this.inicio,
				this.procesadores, this.instancia);
	}
}
